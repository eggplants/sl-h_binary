/*                   *
 *                   *
 *                   */

extern int add_D51_coach();
extern int add_D51_coach_r();
extern int add_sl();
extern int add_man();
extern int add_smoke();
extern int add_smoke_r();
extern int add_cross();
extern int begin_gate();
extern int end_gate();
extern int x_gate();
extern void end_proc();
